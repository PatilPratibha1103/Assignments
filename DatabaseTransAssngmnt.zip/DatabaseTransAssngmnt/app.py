from flask import Flask, request, jsonify
import cassandra
import pymongo
import urllib
import mysql.connector as connection
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
import json

app = Flask(__name__)

@app.route('/via_postman/createtable', methods=['POST']) # for calling the API from Postman/SOAPUI
def database_transaction_via_postman():
    if (request.method=='POST'):
        dbtype=request.json['dbtype']
        tblname=request.json['tblname']
        columns = request.json['columns']
        if dbtype=='cassandra':
            try:
                cloud_config = {
                'secure_connect_bundle': 'D:\DATA SCIENCE\secure-connect-Ds.zip'
                }
                auth_provider = PlainTextAuthProvider('hPJWFtqiTGBRlSpwxMbTAEkM',
                                                      'CuyYrjYZyIiYejnxQqDMN6Jaqf3lGNzNroEumAatfsRe,XR1ZS7_KUDCXZSizZxkyMSlPuT5-4ew+MW4KZyA4B.KYu8Pal_4-28s8OcJZiiF5x5zpKlbK02XaATigpXu')
                cluster = Cluster(cloud=cloud_config, auth_provider=auth_provider)
                session = cluster.connect('Test')

                colstocreate = ''
                for columnKey, columnVlaue in columns.items():
                    try:
                        colstocreate = colstocreate + " " + columnKey + " " + columnVlaue + ","
                    except Exception as e:
                        return jsonify(str(e))
                colstocreate = colstocreate[:-1]
                qry = "create table "+tblname+" ( "+colstocreate+" )"
                session.execute(qry)
                result = 'Table with name '+tblname+' created successfully'
                return jsonify(result)
            except Exception as e:
                result = 'OOps! something went wrong!! ' + e
                return jsonify(result)

        elif dbtype=='mongodb':
            try:
                client = pymongo.MongoClient("mongodb+srv://datascience:" + urllib.parse.quote("Pr@11tibh@") + "@cluster0.tqfe6.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
                db=client["DataScience"]
                collection = db[str(tblname)]
                return jsonify('Table created')
            except Exception as e:
                result = 'OOps! something went wrong!! '+ e
                return jsonify(result)

        elif dbtype=='mysql':

            try:
                mydb = connection.connect(host="localhost", database='Student', user="root", passwd="Pr@11tibh@", port=3307,
                                          use_pure=True)
                # check if the connection is established
                print(mydb.is_connected())
                cursor = mydb.cursor()  # create a cursor to execute queries
                colstocreate=''
                for columnKey,columnVlaue in columns.items():
                    try:
                        colstocreate =colstocreate+ " "+columnKey+" "+columnVlaue+","
                    except Exception as e:
                        mydb.close()
                        return jsonify(str(e))
                colstocreate = colstocreate[:-1]
                query = "create table if not exists " + tblname + " ( " + colstocreate + " )";
                cursor.execute(query)
                mydb.commit()
                return jsonify("Table Created!!")
                mydb.close()

            except Exception as e:
                mydb.close()
                return jsonify(str(e))


@app.route('/via_postman/insertrecord', methods=['POST']) # for calling the API from Postman/SOAPUI
def insert_transaction_via_postman():
    if (request.method=='POST'):

        dbtype=request.json['dbtype']
        tblname=request.json['tblname']
        columns = request.json['columns']
        values= request.json['values']
        if dbtype=='cassandra':
            try:
                cloud_config = {
                'secure_connect_bundle': 'D:\DATA SCIENCE\secure-connect-Ds.zip'
                }
                auth_provider = PlainTextAuthProvider('hPJWFtqiTGBRlSpwxMbTAEkM',
                                                      'CuyYrjYZyIiYejnxQqDMN6Jaqf3lGNzNroEumAatfsRe,XR1ZS7_KUDCXZSizZxkyMSlPuT5-4ew+MW4KZyA4B.KYu8Pal_4-28s8OcJZiiF5x5zpKlbK02XaATigpXu')
                cluster = Cluster(cloud=cloud_config, auth_provider=auth_provider)
                session = cluster.connect('Test')

                try:
                    colstocreate = ''
                    valuestoinsert = ''
                    for columnKey, columnVlaue in columns.items():
                        try:
                            colstocreate = colstocreate + " " +  columnVlaue + ","
                        except Exception as e:
                            return jsonify(str(e))
                    colstocreate = colstocreate[:-1]

                    for columnKey, columnVlaue in values.items():
                        try:
                            valuestoinsert = valuestoinsert + " '" + str(columnVlaue) + "',"
                        except Exception as e:
                            return jsonify(str(e))
                    valuestoinsert = valuestoinsert[:-1]

                except Exception as e:
                    return jsonify(e)

                qry = "insert into " + tblname + " ( " + colstocreate + " ) values ("+ valuestoinsert+")";
                session.execute(qry)
                result = 'values inserted successfully'
                return jsonify(result)
            except Exception as e:
                result= 'OOps! something went wrong!! ' + e
                return jsonify(result)

        elif dbtype=='mongodb':
            try:
                client = pymongo.MongoClient("mongodb+srv://datascience:" + urllib.parse.quote("Pr@11tibh@") + "@cluster0.tqfe6.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
                db=client["DataScience"]
                collection = db[str(tblname)]
                collection.insert_one(values)
                result = 'values inserted successfully'
                return jsonify(result)
            except:
                result = 'OOps! something went wrong!!'
                return jsonify(result)

        elif dbtype=='mysql':

            try:
                mydb = connection.connect(host="localhost", database='Student', user="root", passwd="Pr@11tibh@", port=3307,
                                          use_pure=True)
                # check if the connection is established
                print(mydb.is_connected())

                try:
                    colstocreate = ''
                    valuestoinsert = ''
                    for columnKey, columnVlaue in columns.items():
                        try:
                            colstocreate = colstocreate + " " + columnVlaue + ","
                        except Exception as e:
                            return jsonify(str(e))
                    colstocreate = colstocreate[:-1]

                    for columnKey, columnVlaue in values.items():
                        try:
                            valuestoinsert = valuestoinsert + " '" + columnVlaue + "',"
                        except Exception as e:
                            return jsonify(str(e))
                    valuestoinsert = valuestoinsert[:-1]

                except Exception as e:
                    return jsonify(e)

                query = "insert into " + tblname + " ( " + colstocreate + " ) values (" + valuestoinsert + ")";

                cursor = mydb.cursor()  # create a cursor to execute queries
                cursor.execute(query)
                mydb.commit()
                result = 'values inserted successfully'
                return jsonify(result)
                mydb.close()

            except Exception as e:
                mydb.close()
                return jsonify(str(e))

@app.route('/via_postman/updaterecord', methods=['POST']) # for calling the API from Postman/SOAPUI
def update_transaction_via_postman():
    if (request.method=='POST'):

        dbtype=request.json['dbtype']
        tblname=request.json['tblname']
        colsVal = request.json['colsVal']
        condition= request.json['condition']
        if dbtype=='cassandra':
            try:
                cloud_config = {
                'secure_connect_bundle': 'D:\DATA SCIENCE\secure-connect-Ds.zip'
                }
                auth_provider = PlainTextAuthProvider('hPJWFtqiTGBRlSpwxMbTAEkM',
                                                      'CuyYrjYZyIiYejnxQqDMN6Jaqf3lGNzNroEumAatfsRe,XR1ZS7_KUDCXZSizZxkyMSlPuT5-4ew+MW4KZyA4B.KYu8Pal_4-28s8OcJZiiF5x5zpKlbK02XaATigpXu')
                cluster = Cluster(cloud=cloud_config, auth_provider=auth_provider)
                session = cluster.connect('Test')

                try:
                    colstocreate = ''
                    valuestoinsert = ''
                    for columnKey, columnVlaue in colsVal.items():
                        try:
                            colstocreate = colstocreate + " " + columnKey + " = '" + columnVlaue + "',"
                        except Exception as e:
                            return jsonify(str(e))
                    colstocreate = colstocreate[:-1]

                    for columnKey, columnVlaue in condition.items():
                        try:
                            valuestoinsert = valuestoinsert +" " + columnKey + " = '" + str(columnVlaue) + "',"
                        except Exception as e:
                            return jsonify(str(e))
                    valuestoinsert ="Where " +  valuestoinsert[:-1]

                except Exception as e:
                    return jsonify(e)

                qry = "update " + tblname + " set " + colstocreate + " "+ valuestoinsert+"";
                session.execute(qry)
                result = 'values updated successfully'
                return jsonify(result)
            except Exception as e:
                result= 'OOps! something went wrong!! ' + e
                return jsonify(result)

        elif dbtype=='mongodb':
            try:
                client = pymongo.MongoClient("mongodb+srv://datascience:" + urllib.parse.quote("Pr@11tibh@") + "@cluster0.tqfe6.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
                db=client["DataScience"]
                collection = db[str(tblname)]
                oldv=colsVal
                newv=  condition
                #collection.update_many( colsVal,'"$set":' + condition)
                collection.find_and_modify(colsVal,update = condition)
                result = 'values updated successfully'
                return jsonify(result)
            except Exception as e:
                result= 'OOps! something went wrong!! ' + e
                return jsonify(result)

        elif dbtype=='mysql':

            try:
                mydb = connection.connect(host="localhost", database='Student', user="root", passwd="Pr@11tibh@", port=3307,
                                          use_pure=True)
                # check if the connection is established
                print(mydb.is_connected())

                try:
                    colstocreate = ''
                    valuestoinsert = ''
                    for columnKey, columnVlaue in colsVal.items():
                        try:
                            colstocreate = colstocreate + " " + columnKey + " = '" + columnVlaue + "',"
                        except Exception as e:
                            return jsonify(str(e))
                    colstocreate = colstocreate[:-1]

                    for columnKey, columnVlaue in condition.items():
                        try:
                            valuestoinsert = valuestoinsert + " " + columnKey + " = '" + str(columnVlaue) + "',"
                        except Exception as e:
                            return jsonify(str(e))
                    valuestoinsert = "Where " + valuestoinsert[:-1]

                except Exception as e:
                    return jsonify(e)

                query = "update " + tblname + " set " + colstocreate + " " + valuestoinsert + "";

                cursor = mydb.cursor()  # create a cursor to execute queries
                cursor.execute(query)
                mydb.commit()
                result = 'values updated successfully'
                return jsonify(result)
                mydb.close()

            except Exception as e:
                mydb.close()
                return jsonify(str(e))

@app.route('/via_postman/deleterecord', methods=['POST']) # for calling the API from Postman/SOAPUI
def delete_transaction_via_postman():
    if (request.method=='POST'):

        dbtype=request.json['dbtype']
        tblname=request.json['tblname']
        condition= request.json['condition']
        if dbtype=='cassandra':
            try:
                cloud_config = {
                'secure_connect_bundle': 'D:\DATA SCIENCE\secure-connect-Ds.zip'
                }
                auth_provider = PlainTextAuthProvider('hPJWFtqiTGBRlSpwxMbTAEkM',
                                                      'CuyYrjYZyIiYejnxQqDMN6Jaqf3lGNzNroEumAatfsRe,XR1ZS7_KUDCXZSizZxkyMSlPuT5-4ew+MW4KZyA4B.KYu8Pal_4-28s8OcJZiiF5x5zpKlbK02XaATigpXu')
                cluster = Cluster(cloud=cloud_config, auth_provider=auth_provider)
                session = cluster.connect('Test')
                con= ''
                for key, val in condition.items():
                    con = con + key+" = '"+ str(val)+"'"

                qry = "delete from " + tblname + " where " + con;

                session.execute(qry)
                result = 'deleted successfully'
                return jsonify(result)
            except Exception as e:
                result= 'OOps! something went wrong!! ' + e
                return jsonify(result)

        elif dbtype=='mongodb':
            try:
                client = pymongo.MongoClient("mongodb+srv://datascience:" + urllib.parse.quote("Pr@11tibh@") + "@cluster0.tqfe6.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
                db=client["DataScience"]
                collection = db[str(tblname)]
                collection.delete_one(condition)
                result = 'deleted successfully'
                return jsonify(result)
            except Exception as e:
                result= 'OOps! something went wrong!! ' + e
                return jsonify(result)

        elif dbtype=='mysql':

            try:
                mydb = connection.connect(host="localhost", database='Student', user="root", passwd="Pr@11tibh@", port=3307,
                                          use_pure=True)
                # check if the connection is established
                print(mydb.is_connected())

                con = ''
                for key, val in condition.items():
                    con = con + key + " = '" + val +"'"


                query = "delete from " + tblname + " where  " + con;

                cursor = mydb.cursor()  # create a cursor to execute queries
                cursor.execute(query)
                mydb.commit()
                result = 'deleted successfully'
                return jsonify(result)
                mydb.close()

            except Exception as e:
                mydb.close()
                return jsonify(str(e))

@app.route('/via_postman/BulkInsert', methods=['POST']) # for calling the API from Postman/SOAPUI
def bulkinsert_transaction_via_postman():
    if (request.method=='POST'):

        dbtype=request.json['dbtype']
        tblname=request.json['tblname']
        filelocation = request.json['filelocation']

        if dbtype=='cassandra':
            try:
                cloud_config = {
                'secure_connect_bundle': 'D:\DATA SCIENCE\secure-connect-Ds.zip'
                }
                auth_provider = PlainTextAuthProvider('hPJWFtqiTGBRlSpwxMbTAEkM',
                                                      'CuyYrjYZyIiYejnxQqDMN6Jaqf3lGNzNroEumAatfsRe,XR1ZS7_KUDCXZSizZxkyMSlPuT5-4ew+MW4KZyA4B.KYu8Pal_4-28s8OcJZiiF5x5zpKlbK02XaATigpXu')
                cluster = Cluster(cloud=cloud_config, auth_provider=auth_provider)
                session = cluster.connect('Test')

                f = open(filelocation)
                next(f)
                for i in f:
                    i = i.rstrip("\n")
                    qry = "insert into " + tblname + "(id,Col1,Col2) values ( " + i + ")";
                    session.execute(qry)
                result = 'file data inserted successfully'
                return jsonify(result)
            except Exception as e:
                result= 'OOps! something went wrong!! ' + e
                return jsonify(result)

        elif dbtype=='mongodb':
            try:
                client = pymongo.MongoClient("mongodb+srv://datascience:" + urllib.parse.quote("Pr@11tibh@") + "@cluster0.tqfe6.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
                db=client["DataScience"]
                collection = db[str(tblname)]

                f = open(filelocation,'r')
                next(f)
                for i in f:
                    i = i.rstrip("\n'")
                    i = json.loads(i)
                    collection.insert_one(i)

                result = 'file data inserted successfully'
                return jsonify(result)
            except Exception as e:
                result= 'OOps! something went wrong!! ' + e
                return jsonify(result)

        elif dbtype=='mysql':

            try:
                mydb = connection.connect(host="localhost", database='Student', user="root", passwd="Pr@11tibh@", port=3307,
                                          use_pure=True)
                # check if the connection is established
                print(mydb.is_connected())

                f = open(filelocation)
                next(f)
                for i in f:
                    i=i.replace(';',',').rstrip("\n")
                    query = "insert into " + tblname + " values ( " + i + ")";
                    cursor = mydb.cursor()  # create a cursor to execute queries
                    cursor.execute(query)
                    mydb.commit()
                result = 'file data inserted successfully'
                return jsonify(result)
                mydb.close()

            except Exception as e:
                mydb.close()
                return jsonify(str(e))

@app.route('/via_postman/Download', methods=['POST']) # for calling the API from Postman/SOAPUI
def download_transaction_via_postman():
    if (request.method=='POST'):

        dbtype=request.json['dbtype']
        tblname=request.json['tblname']
        if dbtype=='cassandra':
            try:
                cloud_config = {
                'secure_connect_bundle': 'D:\DATA SCIENCE\secure-connect-Ds.zip'
                }
                auth_provider = PlainTextAuthProvider('hPJWFtqiTGBRlSpwxMbTAEkM',
                                                      'CuyYrjYZyIiYejnxQqDMN6Jaqf3lGNzNroEumAatfsRe,XR1ZS7_KUDCXZSizZxkyMSlPuT5-4ew+MW4KZyA4B.KYu8Pal_4-28s8OcJZiiF5x5zpKlbK02XaATigpXu')
                cluster = Cluster(cloud=cloud_config, auth_provider=auth_provider)
                session = cluster.connect('Test')

                qry = "select * from " + tblname ;
                result = session.execute(qry)

                with open('cassandradata.csv', 'w+') as csv_file:
                    for data in result:
                        csv_file.write(str(data))

                result = 'exported successfully'
                return jsonify(result)
            except Exception as e:
                result= 'OOps! something went wrong!! ' + e
                return jsonify(result)

        elif dbtype=='mongodb':
            try:
                client = pymongo.MongoClient("mongodb+srv://datascience:" + urllib.parse.quote("Pr@11tibh@") + "@cluster0.tqfe6.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
                db=client["DataScience"]
                collection = db[str(tblname)]
                datadb = collection.find()

                with open('mongodb.csv', 'w') as csv_file:
                    for data in datadb:
                        s=str(data)
                        csv_file.write(s)


                result = 'exported successfully'
                return jsonify(result)
            except Exception as e:
                result= 'OOps! something went wrong!! ' + e
                return jsonify(result)

        elif dbtype=='mysql':

            try:
                mydb = connection.connect(host="localhost", database='Student', user="root", passwd="Pr@11tibh@", port=3307,
                                          use_pure=True)
                # check if the connection is established
                print(mydb.is_connected())

                query = "select * from " + tblname ;

                cursor = mydb.cursor()  # create a cursor to execute queries
                cursor.execute(query)

                with open('mysqldata.csv', 'w') as csv_file:
                    for data in cursor.fetchall():
                        csv_file.write(str(data))

                result = 'exported successfully'
                return jsonify(result)
                mydb.close()

            except Exception as e:
                mydb.close()
                return jsonify(str(e))


if __name__ == '__main__':
    app.run()
